package org.junit.tests.validation.anotherpackage;

public class Sub extends Super {
	
}
